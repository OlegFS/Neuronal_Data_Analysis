function H = entropy_jk(p)
% function H = entropy_jk(p)
%   p   vector with observed frequencies of all words
%   H   jackknife estimate of entropy

% jack-knifed entropy estimator (paninski, p. 1198)



