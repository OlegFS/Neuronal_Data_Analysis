function H = entropy_cae(p)

% function H = entropy_cae(p)
%   p   vector with observed frequencies of all words
%   H   coverage adjusted estimate of entropy